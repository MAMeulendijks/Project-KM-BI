"""
Single Tube Example
by Nick van Osta
"""
import matplotlib.pyplot as plt
import numpy as np
import time

import circadapt
import os
circadapt.DEFAULT_PATH_TO_CIRCADAPT = os.getcwd() + "\\src\\CircAdaptLib.dll"
circadapt.load_plugin_components('src\\TimingsNetwork.dll')
circadapt.load_plugin_components('src\\NetworkTrigger.dll')
circadapt.load_plugin_components('src\\NetworkLink.dll')
circadapt.load_plugin_components('src\\NetworkNode.dll')
circadapt.load_plugin_components('src\\Thorax.dll')


class VanOsta2024_Breathing_Thorax(circadapt.VanOsta2024):
    def __init__(self,
                 solver: str = 'forward_euler',
                 path_to_circadapt: str = None,
                 model_state: dict = None,
                 ):
        self._local_save_reference = False
        super().__init__(solver, path_to_circadapt, model_state)

        

    def build(self):
        self.add_component('TimingsNetwork', 'Network')
        self.add_smart_component('ArtVen', build='SystemicCirculation')
        self.add_smart_component('ArtVen', build='PulmonaryCirculation')
        
        # Customized heart
        options = {
            'chamber_type': "Chamber",
            'triseg_type': "TriSeg",
            'patch_type': "Patch",
            'valve_type': "Valve",
            'PuArt': 'PuArt',
            'SyVen': 'SyVen',
            'PuVen': 'PuVen',
            'SyArt': 'SyArt',
            }
        # defaults
        base = ""

        # Create Bag
        self.add_component('Thorax', 'Peri', base[:-1])
        
        # add atria
        self.add_component(options['chamber_type'], 'La', base+'Peri')
        self.add_component(options['patch_type'], 'pLa0', base+'Peri.La.wLa')
        self.add_component(options['chamber_type'], 'Ra', base+'Peri')
        self.add_component(options['patch_type'], 'pRa0', base+'Peri.Ra.wRa')

        # add ventricles
        self.add_component(options['triseg_type'], 'TriSeg', base+'Peri')
        self.add_component(options['patch_type'], 'pLv0', base+'Peri.TriSeg.wLv')
        self.add_component(options['patch_type'], 'pSv0', base+'Peri.TriSeg.wSv')
        self.add_component(options['patch_type'], 'pRv0', base+'Peri.TriSeg.wRv')

        # add valves
        self.add_component(options['valve_type'], 'SyVenRa', base+'Peri')
        self.add_component(options['valve_type'], 'RaRv', base+'Peri')
        self.add_component(options['valve_type'], 'RvPuArt', base+'Peri')
        self.add_component(options['valve_type'], 'PuVenLa', base+'Peri')
        self.add_component(options['valve_type'], 'LaLv', base+'Peri')
        self.add_component(options['valve_type'], 'LvSyArt', base+'Peri')

        # Link components
        self.set_component('Peri.SyVenRa.prox', options['SyVen'])
        self.set_component('Peri.SyVenRa.dist', 'Peri.Ra')
        self.set_component('Peri.RaRv.prox', 'Peri.Ra')
        self.set_component('Peri.RaRv.dist', 'Peri.TriSeg.cRv')
        self.set_component('Peri.RvPuArt.prox', 'Peri.TriSeg.cRv')
        self.set_component('Peri.RvPuArt.dist', options['PuArt'])

        self.set_component('Peri.PuVenLa.prox', options['PuVen'])
        self.set_component('Peri.PuVenLa.dist', 'Peri.La')
        self.set_component('Peri.LaLv.prox', 'Peri.La')
        self.set_component('Peri.LaLv.dist', 'Peri.TriSeg.cLv')
        self.set_component('Peri.LvSyArt.prox', 'Peri.TriSeg.cLv')
        self.set_component('Peri.LvSyArt.dist', options['SyArt'])

        self.set_component('Peri.SyVenRa.adaptation_cavity', 'SyVen')
        self.set_component('Peri.RaRv.adaptation_cavity', 'PuArt')
        self.set_component('Peri.RvPuArt.adaptation_cavity', 'PuArt')
        self.set_component('Peri.PuVenLa.adaptation_cavity', 'PuVen')
        self.set_component('Peri.LaLv.adaptation_cavity', 'SyArt')
        self.set_component('Peri.LvSyArt.adaptation_cavity', 'SyArt')

        # Parameterize components
        self.set('Model.'+base+'Peri.TriSeg.V', 44e-6)
        self.set('Model.'+base+'Peri.TriSeg.Y', 34.6e-3)

        self.set('Model.'+base+'Peri.TriSeg.cLv.V',  100e-6)
        self.set('Model.'+base+'Peri.TriSeg.cRv.V',  100e-6)
        self.set('Model.'+base+'Peri.La.V',  100e-6)
        self.set('Model.'+base+'Peri.Ra.V',  100e-6)
        
        

        self.add_smart_component('PressureFlowControl')

        # # manually set papillary muscles
        self.set_component("Peri.RaRv.wPapMus", "Peri.TriSeg.wRv")
        self.set_component("Peri.LaLv.wPapMus", "Peri.TriSeg.wLv")

        # PFC 
        self.set_component('PFC.circulation_volume_object', 'SyArt')
        self.set_component('PFC.circulation_volume_object', 'SyVen')
        self.set_component('PFC.circulation_volume_object', 'PuArt')
        self.set_component('PFC.circulation_volume_object', 'PuVen')
        self.set_component('PFC.circulation_volume_object', 'Peri.La')
        self.set_component('PFC.circulation_volume_object', 'Peri.Ra')
        self.set_component('PFC.circulation_volume_object', 'Peri.TriSeg.cLv')
        self.set_component('PFC.circulation_volume_object', 'Peri.TriSeg.cRv')
        self['PFC']['fac'] = 0.25
        
        # Build network
        self.add_component('NetworkNode', 'Ra', 'Network')
        self.set_component('Network.Ra.patch', 'Peri.Ra.wRa.pRa0')
        self.add_component('NetworkNode', 'La', 'Network')
        self.set_component('Network.La.patch', 'Peri.La.wLa.pLa0')
        self.add_component('NetworkNode', 'Sv', 'Network')
        self.set_component('Network.Sv.patch', 'Peri.TriSeg.wSv.pSv0')
        self.add_component('NetworkNode', 'Lv', 'Network')
        self.set_component('Network.Lv.patch', 'Peri.TriSeg.wLv.pLv0')
        self.add_component('NetworkNode', 'Rv', 'Network')
        self.set_component('Network.Rv.patch', 'Peri.TriSeg.wRv.pRv0')
        
        # Fast conduction
        self.add_component('NetworkLink', 'La', 'Network.Ra')
        self.set_component('Network.La.to', 'Network.Ra.La')

        self.add_component('NetworkLink', 'Sv', 'Network.Ra')
        self.set_component('Network.Sv.to', 'Network.Ra.Sv')

        self.add_component('NetworkLink', 'Lv', 'Network.Ra')
        self.set_component('Network.Lv.to', 'Network.Ra.Lv')

        self.add_component('NetworkLink', 'Rv', 'Network.Ra')
        self.set_component('Network.Rv.to', 'Network.Ra.Rv')

        # Slow conduction
        self.add_component('NetworkLink', 'Sv', 'Network.Rv')
        self.set_component('Network.Sv.to', 'Network.Rv.Sv')

        self.add_component('NetworkLink', 'Lv', 'Network.Sv')
        self.set_component('Network.Lv.to', 'Network.Sv.Lv')

        self.add_component('NetworkLink', 'Sv', 'Network.Lv')
        self.set_component('Network.Sv.to', 'Network.Lv.Sv')


        self.add_component('NetworkLink', 'Rv', 'Network.Sv')
        self.set_component('Network.Rv.to', 'Network.Sv.Rv')
        self['NetworkLink']['Dt'] = [0.0, 0.15, 0.15, 0.15, 0.05, 0.05, 0.05, 0.05]
        

    def set_reference(self):
           self['Chamber']['buckling'] = True
           self['Valve']['soft_closure'] = True
           self['Valve']['papillary_muscles'] = False

           self['Solver']['dt'] = 0.001
           self['Solver']['dt_export'] = 0.002
           # self.set('Solver.order',  2)

           self.set('Model.t_cycle', 0.85)
           self['ArtVen']['p0'] = np.array([6306.25832487, 1000.        ])
           self['ArtVen']['q0'] = np.array([4.5e-05, 4.5e-05])
           self['ArtVen']['k'] = np.array([1., 2.])
           self['Tube0D']['l'] = np.array([0.4, 0.4, 0.2, 0.2])
           self['Tube0D']['A_wall'] = np.array([1.12362733e-04, 6.57883944e-05, 9.45910889e-05, 8.22655361e-05])
           self['Tube0D']['k'] = np.array([1.66666667, 2.33333333, 1.66666667, 2.33333333])
           self['Tube0D']['p0'] = np.array([12162.50457811,   287.7083132 ,  2132.51755623,   830.54673184])
           self['Tube0D']['A0'] = np.array([0.0004983 , 0.00049909, 0.00047138, 0.00050803])
           self['Tube0D']['target_wall_stress'] = np.array([500000., 500000., 500000., 500000.])
           self['Tube0D']['target_mean_flow'] = np.array([0.17, 0.17, 0.17, 0.17])
           self['Thorax']['k'] = np.array([10.])
           self['Thorax']['p_ref'] = np.array([0.]) # 1000
           self['Thorax']['V_ref'] = np.array([0.00054267])
           self['Patch']['Am_ref'] = np.array([0.00425687, 0.00401573, 0.00966859, 0.00289936, 0.01084227])
           self['Patch']['V_wall'] = np.array([4.46069398e-06, 2.14548521e-06, 7.35720515e-05, 1.88904978e-05, 3.67720116e-05,])
           self['Patch']['v_max'] = np.array([14., 14.,  7.,  7.,  7.])
           self['Patch']['l_se0'] = np.array([0.04, 0.04, 0.04, 0.04, 0.04])
           self['Patch']['l_s0'] = np.array([1.8, 1.8, 1.8, 1.8, 1.8])
           self['Patch']['l_s_ref'] = np.array([2., 2., 2., 2., 2.])
           self['Patch']['dl_s_pas'] = np.array([0.6, 0.6, 0.6, 0.6, 0.6])
           self['Patch']['Sf_pas'] = np.array([2248.53598   , 2684.76100348,  731.24545453,  729.06063771, 749.47694522,])
           self['Patch']['tr'] = np.array([0.4 , 0.4 , 0.25, 0.25, 0.25])
           self['Patch']['td'] = np.array([0.4 , 0.4 , 0.25, 0.25, 0.25])
           self['Patch']['time_act'] = np.array([0.15 , 0.15 , 0.425, 0.425, 0.425])
           self['Patch']['Sf_act'] = np.array([ 84000.,  84000., 120000., 120000., 120000.])
           self['Patch']['fac_Sf_tit'] = np.array([0.01, 0.01, 0.01, 0.01, 0.01])
           self['Patch']['k1'] = np.array([10., 10., 10., 10., 10.])
           self['Patch']['dt'] = np.array([0., 0., 0., 0., 0.])
           self['Patch']['C_rest'] = np.array([0., 0., 0., 0., 0.])
           self['Patch']['l_si0'] = np.array([1.51, 1.51, 1.51, 1.51, 1.51])
           self['Patch']['LDAD'] = np.array([1.057, 1.057, 1.057, 1.057, 1.057])
           self['Patch']['ADO'] = np.array([0.65, 0.65, 0.65, 0.65, 0.65])
           self['Patch']['LDCC'] = np.array([4., 4., 4., 4., 4.])
           self['Patch']['SfPasMaxT'] = np.array([320000., 320000.,  16000.,  16000.,  16000.])
           self['Patch']['SfPasActT'] = np.array([40000., 40000., 20000., 20000., 20000.])
           self['Patch']['FacSfActT'] = np.array([0.8, 0.8, 1. , 1. , 1. ])
           self['Patch']['LsPasActT'] = np.array([2.42, 2.42, 2.42, 2.42, 2.42])
           self['Patch']['adapt_gamma'] = np.array([0.5, 0.5, 0.5, 0.5, 0.5])
           self['Patch']['transmat00'] = np.array([-0.5751, -0.5751, -0.5751, -0.5751, -0.5751])
           self['Patch']['transmat01'] = np.array([-0.7851, -0.7851, -0.7851, -0.7851, -0.7851])
           self['Patch']['transmat02'] = np.array([0.6063, 0.6063, 0.6063, 0.6063, 0.6063])
           self['Patch']['transmat03'] = np.array([-0.5565, -0.5565, -0.5565, -0.5565, -0.5565])
           self['Patch']['transmat10'] = np.array([-0.1279, -0.1279, -0.1279, -0.1279, -0.1279])
           self['Patch']['transmat11'] = np.array([0.0999, 0.0999, 0.0999, 0.0999, 0.0999])
           self['Patch']['transmat12'] = np.array([0.2066, 0.2066, 0.2066, 0.2066, 0.2066])
           self['Patch']['transmat13'] = np.array([-1.8441, -1.8441, -1.8441, -1.8441, -1.8441])
           self['Patch']['transmat20'] = np.array([-0.1865, -0.1865, -0.1865, -0.1865, -0.1865])
           self['Patch']['transmat21'] = np.array([-0.201, -0.201, -0.201, -0.201, -0.201])
           self['Patch']['transmat22'] = np.array([1.3195, 1.3195, 1.3195, 1.3195, 1.3195])
           self['Patch']['transmat23'] = np.array([-11.8745, -11.8745, -11.8745, -11.8745, -11.8745])
           self['Valve']['adaptation_A_open_fac'] = np.array([1., 1., 1., 1., 1., 1.])
           self['Valve']['A_open'] = np.array([0.00049916, 0.00047155, 0.00047155, 0.00050805, 0.00049835,
                  0.00049835])
           self['Valve']['A_leak'] = np.array([1.e-09, 1.e-09, 1.e-09, 1.e-09, 1.e-09, 1.e-09])
           self['Valve']['l'] = np.array([0.01260512, 0.01225144, 0.01225144, 0.01271679, 0.01259479,
                  0.01259479])
           self['Valve']['L_fac_prox'] = np.array([0.75, 0.75, 0.75, 0.75, 0.75, 0.75])
           self['Valve']['L_fac_dist'] = np.array([0.75, 0.75, 0.75, 0.75, 0.75, 0.75])
           self['Valve']['L_fac_valve'] = np.array([1.5, 1.5, 1.5, 1.5, 1.5, 1.5])
           self['Valve']['rho_b'] = np.array([1050., 1050., 1050., 1050., 1050., 1050.])
           self['Valve']['papillary_muscles'] = np.array([False, False, False, False, False, False])
           self['Valve']['papillary_muscles_slope'] = np.array([100., 100., 100., 100., 100., 100.])
           self['Valve']['papillary_muscles_min'] = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
           self['Valve']['papillary_muscles_A_open_fac'] = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
           self['Valve']['soft_closure'] = np.array([ True,  True,  True,  True,  True,  True])
           self['Valve']['fraction_A_open_Aext'] = np.array([0.9, 0.9, 0.9, 0.9, 0.9, 0.9])
           # self['Timings']['time_fac'] = np.array([1.])
           # self['Timings']['tau_av'] = np.array([0.150025])
           # self['Timings']['dtau_av'] = np.array([0.])
           # self['Timings']['law_tau_av'] = np.array([1])
           # self['Timings']['law_Ra2La'] = np.array([1])
           # self['Timings']['law_ta'] = np.array([1])
           # self['Timings']['law_tv'] = np.array([1])
           # self['Timings']['c_tau_av0'] = np.array([0.])
           # self['Timings']['c_tau_av1'] = np.array([0.1765])
           # self['Timings']['c_ta_rest'] = np.array([0.])
           # self['Timings']['c_ta_tcycle'] = np.array([0.17647059])
           # self['Timings']['c_tv_rest'] = np.array([0.1])
           # self['Timings']['c_tv_tcycle'] = np.array([0.4])
           self['PFC']['p0'] = np.array([12200.])
           self['PFC']['q0'] = np.array([8.5e-05])
           self['PFC']['stable_threshold'] = np.array([0.0001])
           self['PFC']['is_active'] = np.array([ True])
           self['PFC']['fac'] = np.array([1.])
           self['PFC']['fac_pfc'] = np.array([1.])
           self['PFC']['epsilon'] = np.array([0.4])
           self['TriSeg']['tau'] = np.array([2.])
           self['TriSeg']['ratio_septal_LV_Am'] = np.array([0.3])


           # self.run(stable=True)
           # self.adapt()

           # set target volume

           return

if __name__ == "__main__":
    model = VanOsta2024_Breathing_Thorax(solver='forward_euler')
    model.run(1)
    model.plot()
    