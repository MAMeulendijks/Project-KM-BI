# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 16:54:57 2024

@author: 20182785
"""

import matplotlib.pyplot as plt
import numpy as np
import time
from cardiac_calculations import CardiacCalculator
from plot_functions import HemodynamicPlotter

from _model_thorax import VanOsta2024_Breathing_Thorax
plt.close('all')

# %% Define HRV states to simulate
hrv_states = ['on', 'off']  # HRV states: 'on', 'off'

# Initialize dictionaries to store results
results_breathing_no_hrv = {}
results_breathing_hrv = {}
results_no_breathing_no_hrv = {}
results_no_breathing_hrv = {}

# Initialize lists to store LA stress and strain for plotting (HRV off only)
LA_stress_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}
LA_strain_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}

# %% Loop over HRV states
for include_hrv in hrv_states:
    # Define cycle times based on HRV state
    if include_hrv == 'on':
        cycle_times = [0, 0.857, 0.789, 0.732, 0.789, 0.857]  # sinus rhythm
    elif include_hrv == 'off':
        cycle_times = [0, 0.8, 0.8, 0.8, 0.8, 0.8]

    # Calculate length of breathing cycle
    breath_cycle_time = np.cumsum(cycle_times)[-1]
    n_beats = len(cycle_times) - 1

    # Define states to simulate
    states = ['Healthy', 'HFrEF', 'HFpEF']

    # Iterate over the states
    for State in states:
        # Load model including the thorax
        model = VanOsta2024_Breathing_Thorax()

        for i in range(n_beats):
            model.add_component('NetworkTrigger', str(i), 'Network.Ra')
        
        # Set the start of mechanical triggers 
        model['NetworkTrigger']['time'] = np.cumsum(cycle_times[0:-1])

        # Run hemodynamically stable to ensure 'fair' starting point
        model['Solver']['store_beats'] = 1
        model['General']['t_cycle'] = breath_cycle_time / (len(cycle_times)-1)   # calculate mean cycle time
        model['Thorax']['p_ref'] = 0e3  # turn off pericardial function
        model['Thorax']['p_max'] = 0e3  # turn off thorax for hemodynamic stability

        if State == 'HFrEF':
            model['Patch']['Sf_act'][['pLv0', 'pSv0']] *= 0.461
        elif State == 'HFpEF':
            model['Patch']['k1'][['pLv0', 'pSv0']] *= 1.96

        model.run(stable=True)

        # Set time to simulate back to initial values and deactivate pressure flow control
        model['General']['t_cycle'] = breath_cycle_time
        model['PFC']['is_active'] = False

        # Run the model without breathing cycle
        model.run(10)

        # Calculate cardiac parameters - No breathing
        V_lv = model['Cavity']['V'][:, 'cLv']*1e6  
        flow_aortic_valve = model['Valve']['q'][:,'LvSyArt'] 
        flow_pulmonary_valve = model['Valve']['q'][:,'RvPuArt'] 
        time_points = model['Solver']['t']
        LA_pressure = model['Cavity']['p'][:, 'La'] / 133
        LA_stress = model['Patch']['Sf'][:, 'pLa0'] * 1e-3  # Convert to kPa
        LA_strain = model['Patch']['Ef'][:, 'pLa0']

        # Store LA stress and strain for HRV off (for plotting later)
        if include_hrv == 'off':
            LA_stress_data[State].append(LA_stress)
            LA_strain_data[State].append(LA_strain)

        calculator = CardiacCalculator(time_points, cycle_times, n_beats, V_lv)

        EFs_no_breathing = calculator.calculate_EF(flow_aortic_valve)
        aortic_CO_no_breathing = calculator.calculate_CO(flow_aortic_valve)
        pulmonary_CO_no_breathing = calculator.calculate_CO(flow_pulmonary_valve)
        mean_LA_pressures_no_breathing = calculator.calculate_mean_LA_p(LA_pressure)
        max_LA_stress_no_breathing = calculator.calculate_max_LA_stress(LA_stress)

        # Store results in the corresponding dictionary
        no_breathing_dict = results_no_breathing_hrv if include_hrv == 'on' else results_no_breathing_no_hrv
        if State not in no_breathing_dict:
            no_breathing_dict[State] = {}
        no_breathing_dict[State] = {
            'EFs': EFs_no_breathing,
            'aortic_CO': aortic_CO_no_breathing,
            'pulmonary_CO': pulmonary_CO_no_breathing,
            'mean_LA_pressure': mean_LA_pressures_no_breathing,
            'max_LA_stress': max_LA_stress_no_breathing
        }

        # Parameterize thorax for breathing
        model['Thorax']['dt'] = 0
        model['Thorax']['p_max'] = -0.2666e3  # 2 mmHg is the amplitude 
        model['Thorax']['tr'] = (breath_cycle_time / np.pi)  # no pause

        # Run the model with breathing
        model.run(10)

        # Calculate cardiac parameters - Breathing
        V_lv = model['Cavity']['V'][:, 'cLv']*1e6  
        flow_aortic_valve = model['Valve']['q'][:,'LvSyArt'] 
        flow_pulmonary_valve = model['Valve']['q'][:,'RvPuArt'] 
        time_points = model['Solver']['t']
        LA_pressure = model['Cavity']['p'][:, 'La'] / 133
        LA_stress = model['Patch']['Sf'][:, 'pLa0'] * 1e-3  # Stress in kPa

        calculator = CardiacCalculator(time_points, cycle_times, n_beats, V_lv)

        EFs_breathing = calculator.calculate_EF(flow_aortic_valve)
        aortic_CO_breathing = calculator.calculate_CO(flow_aortic_valve)
        pulmonary_CO_breathing = calculator.calculate_CO(flow_pulmonary_valve)
        mean_LA_pressures_breathing = calculator.calculate_mean_LA_p(LA_pressure)
        max_LA_stress_breathing = calculator.calculate_max_LA_stress(LA_stress)

        # Store results in the corresponding dictionary
        breathing_dict = results_breathing_hrv if include_hrv == 'on' else results_breathing_no_hrv
        if State not in breathing_dict:
            breathing_dict[State] = {}
        breathing_dict[State] = {
            'EFs': EFs_breathing,
            'aortic_CO': aortic_CO_breathing,
            'pulmonary_CO': pulmonary_CO_breathing,
            'mean_LA_pressure': mean_LA_pressures_breathing,
            'max_LA_stress': max_LA_stress_breathing    
        }

# %% Plot LA Stress vs. LA Strain (HRV Off)
plt.figure(figsize=(10, 6))
for state, linestyle, color in zip(['Healthy', 'HFrEF', 'HFpEF'], 
                                   ['-', '--', '-.'], 
                                   ['blue', 'green', 'red']):
    LA_stress = np.concatenate(LA_stress_data[state])
    LA_strain = np.concatenate(LA_strain_data[state])
    plt.plot(LA_strain, LA_stress, label=state, linestyle=linestyle, color=color)

# Customize the plot
plt.title("LA Stress vs. LA Strain (No HRV)")
plt.xlabel("LA Strain (unitless)")
plt.ylabel("LA Stress (kPa)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# %% Print results for inspection
print("Results with HRV and Breathing:", results_breathing_hrv)
print()
print("Results with HRV and No Breathing:", results_no_breathing_hrv)
print()
print("Results without HRV and Breathing:", results_breathing_no_hrv)
print()
print("Results without HRV and No Breathing:", results_no_breathing_no_hrv)

# %% Plotten: breathing + HRV

plotter = HemodynamicPlotter(model, cycle_times, n_beats, breath_cycle_time)

#CO
CO_Healthy = results_breathing_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_breathing_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_breathing_hrv['HFpEF']['aortic_CO']

plotter.compare_CO_states(CO_Healthy, CO_HFrEF, CO_HFpEF)

#mean LA pressure
mean_LA_p_Healthy = results_breathing_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_breathing_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_breathing_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_mean_LA_p_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF)

#max LA stress
max_LA_stress_Healthy = results_breathing_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_breathing_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_breathing_hrv['HFpEF']['max_LA_stress']

plotter.compare_max_LA_stress_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF)

# %% Plotten: breathing + no HRV

plotter = HemodynamicPlotter(model, cycle_times, n_beats, breath_cycle_time)

#CO
CO_Healthy = results_breathing_no_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_breathing_no_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_breathing_no_hrv['HFpEF']['aortic_CO']

plotter.compare_CO_states(CO_Healthy, CO_HFrEF, CO_HFpEF)

#mean LA pressure
mean_LA_p_Healthy = results_breathing_no_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_breathing_no_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_breathing_no_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_mean_LA_p_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF)

#max LA stress
max_LA_stress_Healthy = results_breathing_no_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_breathing_no_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_breathing_no_hrv['HFpEF']['max_LA_stress']

plotter.compare_max_LA_stress_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF)

# %% Plotten: no breathing + HRV

plotter = HemodynamicPlotter(model, cycle_times, n_beats, breath_cycle_time)

#CO
CO_Healthy = results_no_breathing_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_no_breathing_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_no_breathing_hrv['HFpEF']['aortic_CO']

plotter.compare_CO_states(CO_Healthy, CO_HFrEF, CO_HFpEF)

#mean LA pressure
mean_LA_p_Healthy = results_no_breathing_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_no_breathing_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_no_breathing_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_mean_LA_p_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF)

#max LA stress
max_LA_stress_Healthy = results_no_breathing_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_no_breathing_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_no_breathing_hrv['HFpEF']['max_LA_stress']

plotter.compare_max_LA_stress_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF)
