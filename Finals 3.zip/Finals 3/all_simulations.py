# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 16:54:57 2024

@author: 20182785
"""

import matplotlib.pyplot as plt
import numpy as np
import time
from cardiac_calculations import CardiacCalculator
from plot_functions import HemodynamicPlotter

from _model_thorax import VanOsta2024_Breathing_Thorax
plt.close('all')

# %% Define HRV states to simulate
hrv_states = ['off', 'on']  # HRV states: 'off', 'on'

# Initialize dictionaries to store results
results_breathing_no_hrv = {}
results_breathing_hrv = {}
results_no_breathing_no_hrv = {}
results_no_breathing_hrv = {}

# Initialize lists to store LV stress and strain for plotting (HRV off only)
LV_stress_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}
LV_strain_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}

# Initialize lists to store LV pressure and volume for plotting (HRV off only)
LV_pressure_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}
LV_volume_data = {'Healthy': [], 'HFrEF': [], 'HFpEF': []}

# %% Loop over HRV states
for include_hrv in hrv_states:
    # Define cycle times based on HRV state
    if include_hrv == 'on':
        cycle_times = [0, 0.857, 0.789, 0.732, 0.789, 0.857]  # sinus rhythm
    elif include_hrv == 'off':
        cycle_times = [0, 0.8, 0.8, 0.8, 0.8, 0.8]

    # Calculate length of breathing cycle
    breath_cycle_time = np.cumsum(cycle_times)[-1]
    n_beats = len(cycle_times) - 1

    # Define states to simulate
    states = ['Healthy', 'HFrEF', 'HFpEF']

    # Iterate over the states
    for State in states:
        # Load model including the thorax
        model = VanOsta2024_Breathing_Thorax()

        for i in range(n_beats):
            model.add_component('NetworkTrigger', str(i), 'Network.Ra')
        
        # Set the start of mechanical triggers 
        model['NetworkTrigger']['time'] = np.cumsum(cycle_times[0:-1])

        # Run hemodynamically stable to ensure 'fair' starting point
        model['Solver']['store_beats'] = 1
        model['General']['t_cycle'] = breath_cycle_time / (len(cycle_times)-1)   # calculate mean cycle time
        model['Thorax']['p_ref'] = 0e3  # turn off pericardial function
        model['Thorax']['p_max'] = 0e3  # turn off thorax for hemodynamic stability

        if State == 'HFrEF':
            model['Patch']['Sf_act'][['pLv0', 'pSv0']] *= 0.461
        elif State == 'HFpEF':
            model['Patch']['k1'][['pLv0', 'pSv0']] *= 1.96

        model.run(stable=True)

        # Set time to simulate back to initial values and deactivate pressure flow control
        model['General']['t_cycle'] = breath_cycle_time
        model['PFC']['is_active'] = False

        # Run the model without breathing cycle
        model.run(10)

        # Calculate cardiac parameters - No breathing
        V_lv = model['Cavity']['V'][:, 'cLv']*1e6  
        flow_aortic_valve = model['Valve']['q'][:,'LvSyArt'] 
        flow_pulmonary_valve = model['Valve']['q'][:,'RvPuArt'] 
        time_points = model['Solver']['t']
        LA_pressure = model['Cavity']['p'][:, 'La'] / 133
        LA_stress = model['Patch']['Sf'][:, 'pLa0'] * 1e-3  # Convert to kPa
        LV_stress = model['Patch']['Sf'][:, 'pLv0'] * 1e-3  # Convert to kPa
        LV_strain = model['Patch']['Ef'][:, 'pLv0']
        p_lv = model['Cavity']['p'][:, 'cLv']*7.5e-3

        # Store LA stress and strain for HRV off (for plotting later)
        if include_hrv == 'off':
            LV_stress_data[State].append(LV_stress)
            LV_strain_data[State].append(LV_strain)
            LV_pressure_data[State].append(p_lv)
            LV_volume_data[State].append(V_lv)
            

        calculator = CardiacCalculator(time_points, cycle_times, n_beats, V_lv)

        EFs_no_breathing = calculator.calculate_EF(flow_aortic_valve)
        aortic_CO_no_breathing = calculator.calculate_CO(flow_aortic_valve)
        pulmonary_CO_no_breathing = calculator.calculate_CO(flow_pulmonary_valve)
        mean_LA_pressures_no_breathing = calculator.calculate_mean_LA_p(LA_pressure)
        max_LA_stress_no_breathing = calculator.calculate_max_LA_stress(LA_stress)

        # Store results in the corresponding dictionary
        no_breathing_dict = results_no_breathing_hrv if include_hrv == 'on' else results_no_breathing_no_hrv
        if State not in no_breathing_dict:
            no_breathing_dict[State] = {}
        no_breathing_dict[State] = {
            'EFs': EFs_no_breathing,
            'aortic_CO': aortic_CO_no_breathing,
            'pulmonary_CO': pulmonary_CO_no_breathing,
            'mean_LA_pressure': mean_LA_pressures_no_breathing,
            'max_LA_stress': max_LA_stress_no_breathing
        }

        # Parameterize thorax for breathing
        model['Thorax']['dt'] = 0
        model['Thorax']['p_max'] = -0.2666e3  # 2 mmHg is the amplitude 
        model['Thorax']['tr'] = (breath_cycle_time / np.pi)  # no pause

        # Run the model with breathing
        model.run(10)

        # Calculate cardiac parameters - Breathing
        V_lv = model['Cavity']['V'][:, 'cLv']*1e6  
        flow_aortic_valve = model['Valve']['q'][:,'LvSyArt'] 
        flow_pulmonary_valve = model['Valve']['q'][:,'RvPuArt'] 
        time_points = model['Solver']['t']
        LA_pressure = model['Cavity']['p'][:, 'La'] / 133
        LA_stress = model['Patch']['Sf'][:, 'pLa0'] * 1e-3  # Stress in kPa

        calculator = CardiacCalculator(time_points, cycle_times, n_beats, V_lv)

        EFs_breathing = calculator.calculate_EF(flow_aortic_valve)
        aortic_CO_breathing = calculator.calculate_CO(flow_aortic_valve)
        pulmonary_CO_breathing = calculator.calculate_CO(flow_pulmonary_valve)
        mean_LA_pressures_breathing = calculator.calculate_mean_LA_p(LA_pressure)
        max_LA_stress_breathing = calculator.calculate_max_LA_stress(LA_stress)
        
        #print certain parameters
        mean_CO = np.mean(aortic_CO_breathing)
        mLAP = np.mean(LA_pressure)
        max_LA_stress = np.max(LA_stress)
        
        print(State, '-', 'HRV', include_hrv, ',', 'Mean CO:', mean_CO, 'mLAP:', mLAP, 'max LA stress:', max_LA_stress)
        

        # Store results in the corresponding dictionary
        breathing_dict = results_breathing_hrv if include_hrv == 'on' else results_breathing_no_hrv
        if State not in breathing_dict:
            breathing_dict[State] = {}
        breathing_dict[State] = {
            'EFs': EFs_breathing,
            'aortic_CO': aortic_CO_breathing,
            'pulmonary_CO': pulmonary_CO_breathing,
            'mean_LA_pressure': mean_LA_pressures_breathing,
            'max_LA_stress': max_LA_stress_breathing    
        }

# %% Plot LV Stress vs. LV Strain (HRV Off)
plt.figure(figsize=(10, 6))
for state, linestyle, color in zip(['Healthy', 'HFrEF', 'HFpEF'], 
                                   ['-', '--', '-.'], 
                                   ['blue', 'green', 'red']):
    LV_stress = np.concatenate(LV_stress_data[state])
    LV_strain = np.concatenate(LV_strain_data[state])
    plt.plot(LV_strain, LV_stress, label=state, linestyle=linestyle, color=color)
    
plt.title("LV Stress vs. LV Strain (No HRV)")
plt.xlabel("LV Strain (-)")
plt.ylabel("LV Stress (kPa)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
    
# %% Plot LV pressure vs. LV volume (HRV Off)
plt.figure(figsize=(10, 6))
for state, linestyle, color in zip(['Healthy', 'HFrEF', 'HFpEF'], 
                                   ['-', '--', '-.'], 
                                   ['blue', 'green', 'red']):
    LV_pressure = np.concatenate(LV_pressure_data[state])
    LV_volume = np.concatenate(LV_volume_data[state])
    plt.plot(LV_volume, LV_pressure, label=state, linestyle=linestyle, color=color)

plt.title("LV pressure vs. LV volume (No HRV)")
plt.xlabel("LV volume (ml)")
plt.ylabel("LV pressure (mmHg)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# %% Print results for inspection
# print("Results with HRV and Breathing:", results_breathing_hrv)
# print()
# print("Results with HRV and No Breathing:", results_no_breathing_hrv)
# print()
# print("Results without HRV and Breathing:", results_breathing_no_hrv)
# print()
# print("Results without HRV and No Breathing:", results_no_breathing_no_hrv)

# %% Plotten: breathing + HRV

plotter = HemodynamicPlotter(model, cycle_times, n_beats, breath_cycle_time)

#CO
CO_Healthy = results_breathing_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_breathing_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_breathing_hrv['HFpEF']['aortic_CO']

plotter.compare_states(CO_Healthy, CO_HFrEF, CO_HFpEF, ylabel = 'Cardiac Output (L/min)', title ='Comparison of Cardiac Outputs')

#mean LA pressure
mean_LA_p_Healthy = results_breathing_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_breathing_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_breathing_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF, ylabel = 'mean LA pressure (mmHg)', title = 'Comparison of mean LA pressures')

#max LA stress
max_LA_stress_Healthy = results_breathing_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_breathing_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_breathing_hrv['HFpEF']['max_LA_stress']

plotter.compare_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF, ylabel='max LA stress (kPa)', title = 'Comparison of max LA stresses - HRV off')

# %% Plotten: breathing + no HRV

#CO
CO_Healthy = results_breathing_no_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_breathing_no_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_breathing_no_hrv['HFpEF']['aortic_CO']

plotter.compare_states(CO_Healthy, CO_HFrEF, CO_HFpEF, ylabel = 'Cardiac Output (L/min)', title = 'Comparison of Cardiac Outputs')

#mean LA pressure
mean_LA_p_Healthy = results_breathing_no_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_breathing_no_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_breathing_no_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF, ylabel = 'mean LA pressure (mmHg)', title= 'Comparison of mean LA pressures')

#max LA stress
max_LA_stress_Healthy = results_breathing_no_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_breathing_no_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_breathing_no_hrv['HFpEF']['max_LA_stress']

plotter.compare_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF, ylabel='max LA stress (kPa)', title = 'Comparison of max LA stresses - HRV on')

# %% Plotten: no breathing + HRV

#CO
CO_Healthy = results_no_breathing_hrv['Healthy']['aortic_CO']
CO_HFrEF = results_no_breathing_hrv['HFrEF']['aortic_CO']
CO_HFpEF = results_no_breathing_hrv['HFpEF']['aortic_CO']

plotter.compare_states(CO_Healthy, CO_HFrEF, CO_HFpEF, ylabel = 'Cardiac Output (L/min)', title = 'Comparison of Cardiac Outputs')

#mean LA pressure
mean_LA_p_Healthy = results_no_breathing_hrv['Healthy']['mean_LA_pressure']
mean_LA_p_HFrEF = results_no_breathing_hrv['HFrEF']['mean_LA_pressure']
mean_LA_p_HFpEF = results_no_breathing_hrv['HFpEF']['mean_LA_pressure']

plotter.compare_states(mean_LA_p_Healthy, mean_LA_p_HFrEF, mean_LA_p_HFpEF, ylabel = 'mean LA pressure (mmHg)', title = 'Comparison of mean LA pressures')

#max LA stress
max_LA_stress_Healthy = results_no_breathing_hrv['Healthy']['max_LA_stress']
max_LA_stress_HFrEF = results_no_breathing_hrv['HFrEF']['max_LA_stress']
max_LA_stress_HFpEF = results_no_breathing_hrv['HFpEF']['max_LA_stress']

plotter.compare_states(max_LA_stress_Healthy, max_LA_stress_HFrEF, max_LA_stress_HFpEF, ylabel='max LA stress (kPa)', title = 'Comparison of max LA stresses - HRV on')

# %% Plotten: healthy: no breathing + HRV on vs off

# #CO
# CO_HRV_on = results_no_breathing_hrv['Healthy']['aortic_CO']
# CO_HRV_off = results_no_breathing_no_hrv['Healthy']['aortic_CO']

# plotter.compare_healthy(CO_HRV_on, CO_HRV_off, ylabel = 'Cardiac Output (L/min)', title = 'Comparison of Cardiac Outputs - breathing off',ylim = 7)

# #mean LA pressure
# mean_LA_p_HRV_on = results_no_breathing_hrv['Healthy']['mean_LA_pressure']
# mean_LA_p_HRV_off = results_no_breathing_no_hrv['Healthy']['mean_LA_pressure']

# plotter.compare_healthy(mean_LA_p_HRV_on, mean_LA_p_HRV_off, ylabel = 'mean LA pressure (mmHg)', title = 'Comparison of mean LA pressures - breathing off', ylim = 7.5)

# %% Plotten: healthy: breathing + HRV on vs off

# #CO
# CO_HRV_on = results_breathing_hrv['Healthy']['aortic_CO']
# CO_HRV_off = results_breathing_no_hrv['Healthy']['aortic_CO']

# plotter.compare_healthy(CO_HRV_on, CO_HRV_off, ylabel = 'Cardiac Output (L/min)', title = 'Comparison of Cardiac Outputs - breathing on', ylim = 7)

# #mean LA pressure
# mean_LA_p_HRV_on = results_breathing_hrv['Healthy']['mean_LA_pressure']
# mean_LA_p_HRV_off = results_breathing_no_hrv['Healthy']['mean_LA_pressure']

# plotter.compare_healthy(mean_LA_p_HRV_on, mean_LA_p_HRV_off, ylabel = 'mean LA pressure (mmHg)', title = 'Comparison of mean LA pressures - breathing on', ylim = 7.5)

# %% Plotten: healthy: no breathing vs breathing - HRV on vs off

#CO
CO_br_off_HRV_off = results_no_breathing_no_hrv['Healthy']['aortic_CO']
CO_br_off_HRV_on = results_no_breathing_hrv['Healthy']['aortic_CO']
CO_br_on_HRV_off = results_breathing_no_hrv['Healthy']['aortic_CO']
CO_br_on_HRV_on = results_breathing_hrv['Healthy']['aortic_CO']

#mean LA pressure
mLAP_br_off_HRV_off = results_no_breathing_hrv['Healthy']['mean_LA_pressure']
mLAP_br_off_HRV_on = results_no_breathing_no_hrv['Healthy']['mean_LA_pressure']
mLAP_br_on_HRV_off = results_breathing_hrv['Healthy']['mean_LA_pressure']
mLAP_br_on_HRV_on = results_breathing_no_hrv['Healthy']['mean_LA_pressure']

plotter.compare_conditions_healthy(CO_br_off_HRV_off, CO_br_off_HRV_on, CO_br_on_HRV_off, CO_br_on_HRV_on,ylabel = 'Cardiac Output (L/min)', title = 'Comparison of Cardiac Outputs - breathing off',ylim = 7)
plotter.compare_conditions_healthy(mLAP_br_off_HRV_off, mLAP_br_off_HRV_on,mLAP_br_on_HRV_off, mLAP_br_on_HRV_on,ylabel = 'mean LA pressure (mmHg)', title = 'Comparison of mean LA pressures - breathing on', ylim = 7.5)