import matplotlib.pyplot as plt
import numpy as np
import time

from _model_thorax import VanOsta2024_Breathing_Thorax

#%% determine how long you want to simulatie (in this case, 10 times a cardiac cycle of 0.85 sec)
n_beats = 10
t_cycle = 0.85

# %% Make model including the thorax and set the time to be simulated 
model = VanOsta2024_Breathing_Thorax()
model['General']['t_cycle'] = n_beats*t_cycle

# %% Set mechanical triggers to start from the RA (reflecting sinus rhythm)
for i in range(n_beats):
    model.add_component('NetworkTrigger', str(i), 'Network.Ra')
    
# Set the start of mechanical triggers (in this case, constant sinus rhythm with no HR variability) 
model['NetworkTrigger']['time'] = np.cumsum([
    0, 0.85, 0.85, 0.85, 0.85, 0.85, 0.85, 0.85, 0.85, 0.85])
model['General']['t_cycle'] = model['NetworkTrigger']['time'][-1] + 1

# %% Run hemodynamically stable to ensure 'fair' starting point
model['Solver']['store_beats'] = 1
model['General']['t_cycle'] = t_cycle
model['Thorax']['p_ref'] = 0e3 # turn off pericardial function
model['Thorax']['p_max'] = 0e3 # turn off thorax for hemodynamic stability

model.run(stable=True)

# set time to simulate back to inital values, and deactivate pressure flow control
model['General']['t_cycle'] = n_beats * t_cycle
model['PFC']['is_active']=False

# %% run the model without breathing cycle and plot hemodynamics
model.run(1)
model.plot(plt.figure(1, clear=True))

# %% Parameterize thorax
model['Thorax']['dt'] = ....
model['Thorax']['p_max'] = ....
model['Thorax']['tr'] = ...


# %% Run breathing cycle

model.run(1)
model.plot(plt.figure(2, clear=True))

plt.figure(3)
plt.plot(model['Solver']['t']*1e3, model['Thorax']['p'][:, 0] / 133)

